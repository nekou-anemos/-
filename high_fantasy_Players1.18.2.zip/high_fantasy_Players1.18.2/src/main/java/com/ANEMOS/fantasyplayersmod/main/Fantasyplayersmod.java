package com.ANEMOS.fantasyplayersmod.main;

import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.fml.common.Mod;

@Mod("fantasyplayersmod")
public class Fantasyplayersmod {

    public static final String MOD_ID = "fantasyplayersmod";

    public static final CreativeModeTab FANTASYPLAYERSMOD_TAB = new FantasyplayersmodTab();

}
